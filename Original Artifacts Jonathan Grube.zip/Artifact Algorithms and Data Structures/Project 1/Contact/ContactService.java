//Author Name: Jonathan Grube
//Date: 01-25-20201
//CourseID: CS-320
//Description: Contact Service

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStreamReader;


//MAIN CLASS Contact Service
public class ContactService {
	private static Scanner in = new Scanner(System.in);
	ArrayList<Contact> contacts = new ArrayList<>();
	
	public static void main(String[] args) throws IOException {
		addContact();
		editContact();
		deleteContact();
		showMainMenu();
	}
	
	//MAIN MENU
	private static void showMainMenu() {
		System.out.println("1. Add Contact");
		System.out.println("2. Edit Contact");
		System.out.println("3. Delete Contact");
		
		String input;
		do {
			input = in.nextLine();
			switch (input) {
				case "1":
					addContact();
					break;
				case "2":
					editContact();
					break;
				case "3":
					deleteContact();
					break;
				default:
					System.out.print("Choose 1, 2, or 3: ");
			}
		} while (!input.equals("1") && !input.equals("2") && !input.equals("3"));
		System.out.println();
		showMainMenu();
	}
	
	private static void addContact() {
		int i = 0;
		int j = 0;
		String contactIDman;
		String firstNameman;
		String lastNameman;
		String phoneNumman;
		String addressman;
		
		
		//Collect Contact ID within Customer Requirements
		while (i == 0) {
			System.out.println("Enter Contact ID: ");
			String idShield = in.nextLine();
			if (idShield.length() <= 10 && idShield != "") {
				contactIDman = idShield;
				new Contact(contactIDman, "", "", "", "");
				i++;
			} else {
			System.out.println("Contact ID must be 10 Characters or Less and Unique!");
			}
		}
		while (j == 0) {
			System.out.println("Enter First Name: ");
			String idShield = in.nextLine();
			if (idShield.length() <= 10 && idShield != "") {
				firstNameman = idShield;
				String findHelp = contactIDman;
				Contact.set(contactIDnum)
				i = 0;
				j++;
			} else {
				System.out.println("First Name must be 10 Characters or Less!");
			}
		}
		while (i == 0) {
			System.out.println("Enter Last Name: ");
			String idShield = in.nextLine();
			if (idShield.length() <= 10 && idShield != "") {
				String lastName = idShield;
				j = 0;
				i++;
			} else {
				System.out.println("Last Name must be 10 Characters or Less!");
			}
		}
		while (j == 0) {
			System.out.println("Enter 10 Digit Phone Number: ");
			String idShield = in.nextLine();
			if(idShield.length() == 10 && idShield != "") {
				String phoneNum = idShield;
				i = 0;
				j++;
			} else {
				System.out.println("Phone Number must be 10 Digits! ");
			}
		}
		while (i == 0) {
			System.out.println("Enter Address: ");
			String idShield = in.nextLine();
			if(idShield.length() <= 30 && idShield != "") {
				String address = idShield;
				i++;
			} else {
				System.out.println("Address must be 30 Characters or Less!");
			}
		}
		
	}
	
	private static void editContact() {
		
		System.out.println("Enter Contact ID: ");
		String idFilter = in.nextLine();
		//FIXME add if statement to verify with database
	}
	
	private static void deleteContact() {
		
		System.out.println("Enter Contact ID: ");
		String idFilter = in.nextLine();
		//FIXME add if statement to verify with database
	}
	
	}
			