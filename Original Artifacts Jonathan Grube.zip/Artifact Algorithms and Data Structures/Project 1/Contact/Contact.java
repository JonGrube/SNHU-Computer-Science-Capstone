//Author Name: Jonathan Grube
//Date: 01-25-20201
//CourseID: CS-320
//Description: Contact Service


public class Contact {
	private String contactIDnum;
	private String firstNamec;
	private String lastNamec;
	private String phoneNumc;
	private String addressC;
	
	Contact(String contactID, String firstName, String lastName, String phoneNum, String address) {
		this.contactIDnum = "0000000000";
		this.firstNamec = "firstName";
		this.lastNamec = "lastName";
		this.phoneNumc = "##########";
		this.addressC = "address";
	}
	//create new

		// TODO Auto-generated constructor stub
	

	//SET and GET for Contact
	public String getContactID() {
		return contactIDnum;
	}
	public void setContactID(String contactID) {
		this.contactIDnum = contactID;
	}
	public String getFirstName(String firstNamec) {
		return firstNamec;
	}
	public void setFirstName(String firstNamec) {
		this.firstNamec = firstNamec;
	}
	public String getLastName() {
		return lastNamec;
	}
	public void setVontactID(String lastName) {
		this.lastNamec = lastName;
	}
	public String getPhoneNum() {
		return phoneNumc;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNumc = phoneNum;
	}
	public String getAddress() {
		return addressC;
	}
	public void setAddress(String address) {
		this.addressC = address;
	}
	
}
