import java.util.Scanner;
import java.util.Date;

public class AppointmentService {
	
	int i = 0;
	String buffID;
	String buffDate;
	String buffDesc;
	
	while (i != 1) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please make a selection below.\n1. New Appointment\n2. Delete Appointment\n3. Quit"); // Nested If / Else Loops which will populate fields
		String useIn = input.nextLine();                                                                         // with verified inputs according to customer requirements
		                                                                                                        //  and display error messages if input is insufficient
		//Add New Appointment                                                                       
		if (useIn == "1") {
			System.out.println("Enter Appointment ID");
			String newIdIn = input.nextLine();
			//New ID Input is Good
			if (newIdIn != "" && newIdIn.length() <= 10) {
				String buffID = newIdIn;
				System.out.println("Enter Date of AppointmentYYYY-MM-DD (Format Must Match).");
				String newDateIn = input.nextLine();
				
				//Add Date to Appointment
				if (newDateIn.length() == 10) {
					String buffDate = newDateIn;
					System.out.println("Enter Appointment Description");
					String newDescIn = input.nextLine();
					
					//check description
					if (newDescIn.length() <= 50 && newDescIn != "") {
						buffDesc = newDescIn;
						return;
						
					} else {
						System.out.println("Description must be 50 Characters or Less and Cannot be Empty!");
						
					}
				} else {
					//Not adequate input for date
					System.out.println("Wrong Format Entered! (Use YYYY-MM-DD)");
					return;
				}
				}
				//New ID Input is Bad
			} else {
				System.out.println("Appointment ID cannot be Empty and Must Be 10 Characters or Less.");
				return;
				
			}
			}

}
