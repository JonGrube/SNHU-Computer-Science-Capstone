import java.util.Date;
public class Appointment {
	
	public String appID;
	public Date appDate;
	public String appDesc;
	
	public String Appointment(String appID, Date appDate, String appDesc) {

		//Setters
		public void setAppID(String newAppID) {
			this.appID = newAppID;
		}
		public void setAppDate(Date newAppDate) {
			this.appDate = newAppDate;
		}
		public void setAppDesc(String newAppDesc) {
			this.appDesc = newAppDesc;
		}
		//Getters
		public String getAppID() {
			return this.appID;
		}
		public String getAppDate() {
			return this.appDate.toString();
		}
		public String getAppDesc() {
			return this.appDesc;
		}
	}
	
}
