
public class Task {
	
	public String taskID;
	public String taskName;
	public String taskDescrip;
	
	public Task(String buffID, String buffName, String buffDesc) {
		// TODO Auto-generated constructor stub
		taskID = buffID;
		taskName = buffName;
		taskDescrip = buffDesc;
	}
	
	//Setters
	public void setTaskID(String newTaskID) {
		this.taskID = newTaskID;
	}
	public void setTaskName(String newTaskName) {
		this.taskName = newTaskName;
	}
	public void setTaskDescrip(String newTaskDesc) {
		this.taskDescrip = newTaskDesc;
	}
	//Getters
	public String getTaskID() {
		return taskID;
	}
	public String getTaskName() {
		return taskName;
	}
	public String getTaskDescrip() {
		return taskDescrip;
	}
}
