//Author: Jonathan Grube
//Date: 01/31/2021
//Title: Task Manager
//Description: Organizes tasks by ID, and stores Name + Description Information
import java.util.Scanner;

//Main Class
public class TaskService {{
	//Cog Variables
	int i = 0;
	
	//Main Menu
	while (i == 0) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please make a selection below.\n1. New Task\n2. Edit Task\n3. Delete Task\n4. Quit");
		String useIn = input.nextLine();
		
		//Add Task
		String buffID = "id";
		String buffName = "name";
		String buffDesc = "description";
		Task task = new Task(buffID, buffName, buffDesc);
		
		if (useIn == "1") {
			Scanner userIn = new Scanner(System.in);
			
			//New ID
			System.out.println("Enter New Task ID");
			String scanID = input.nextLine();
			if (scanID != "" && scanID.length() <= 10) {
				buffID = scanID;
			} else {
				System.out.println("ID must be No More Than 10 Characters. Try Again.");
				String scanIDgoal = input.nextLine();
				if (scanIDgoal != "" && scanIDgoal.length() <= 10) {
					buffID = scanIDgoal;
					task.setTaskID(buffID);
				} else {
					System.out.println("Max Attempts (2) Reached. Goodbye.");
					i++;
				}
				
			}
			
			//New Name
			System.out.println("Enter New Task Name");
			String scanName = input.nextLine();
			if (scanName != "" && scanName.length() <= 20) {
				buffName = scanName;
			} else {
				System.out.println("Name must be No More Than 10 Characters. Try Again.");
				String scanNamegoal = input.nextLine();
				if (scanNamegoal != "" && scanNamegoal.length() <= 20) {
					buffName = scanNamegoal;
					task.setTaskName(buffName);
				} else {
					System.out.println("Max Attempts (2) Reached. Goodbye.");
				}
				
			}
			
			//New Description
			System.out.println("Enter New Task Description");
			String scanDesc = input.nextLine();
			if (scanDesc != "" && scanDesc.length() <= 30) {
				buffDesc = scanDesc;
			} else {
				System.out.println("Description must be No More Than 30 Characters. Try Again.");
				String scanDescGoal = input.nextLine();
				if (scanDescGoal != "" && scanDescGoal.length() <= 20) {
					buffDesc = scanDescGoal;
					task.setTaskName(buffDesc);
				} else {
					System.out.println("Max Attempts (2) Reached. Goodbye.");
				}
				
			}
			
			//FIXME add task
			
		//Edit Task
		} else if (useIn == "2") {
			System.out.println("Input Task ID to Edit");
			String scanEdit = input.nextLine();
			//FIXME edit task
			
		//Delete Task
		} else if (useIn == "3") {
			System.out.println("Input Task ID to Delete");
			String scanDelete = input.nextLine();
			//FIXME delete task
			
		//Exit
		} else if (useIn == "4") {
			i++;
			
		//Input Rails
		} else {
			System.out.println("\nYou must enter the digit of your selection (1, 2, 3, or 4) and then press the Enter Key");
		}
		
	}
}}
