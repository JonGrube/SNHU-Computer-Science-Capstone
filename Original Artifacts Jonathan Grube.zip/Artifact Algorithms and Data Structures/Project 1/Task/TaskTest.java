import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest() {
	
	@Test
	void taskTest() {
		Task task = new Task("01", "Task01", "This is a test Task named Task01\nID Number: 01");
		assertTrue(task.getTaskID().equals("01"));
		assertTrue(task.getTaskName().equals("Task01"));
		assertTrue(task.getTaskDescrip().equals("This is a test Task named Task01\nID Number: 01"));
	}
};
